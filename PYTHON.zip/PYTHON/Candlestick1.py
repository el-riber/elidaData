import pandas as pd
import mplfinance as mpf

# Load the dataset
file_path = '/Users/elidasouza/Documents/Visualization/pythonProject3/AAL.csv'
aal_data = pd.read_csv(file_path)

# Convert 'Date' to datetime and set as index
aal_data['Date'] = pd.to_datetime(aal_data['Date'], dayfirst=True)
aal_data.set_index('Date', inplace=True)

# Create a candlestick chart
mpf.plot(aal_data[['Open', 'High', 'Low', 'Close']], type='candle', style='charles',
         title='Stock Price Candlestick Chart', ylabel='Price ($)',
         figratio=(12, 8), mav=(3, 6, 9))