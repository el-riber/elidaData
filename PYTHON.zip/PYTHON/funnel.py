import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
data = pd.read_excel('/Users/elidasouza/Documents/Visualization/pythonProject3/Sample - Superstore.xls')

# Aggregate sales data by region
sales_by_region = data.groupby('Region')['Sales'].sum().sort_values(ascending=False).reset_index()

# Create a funnel chart using a bar plot
plt.figure(figsize=(10, 7))
sns.barplot(data=sales_by_region, x='Sales', y='Region', palette='viridis')

# Add annotations for clarity
for index, value in enumerate(sales_by_region['Sales']):
    plt.text(value, index, f'{value:,.0f}')

plt.title('Sales by Region - Funnel Chart Representation', fontsize=16)
plt.xlabel('Total Sales', fontsize=14)
plt.ylabel('Region', fontsize=14)
plt.grid(True, which='major', linestyle='--', linewidth='0.5', color='grey')
plt.box(False)

# Display the funnel chart
plt.show()

