import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset from the uploaded Excel file
file_path ='/Users/elidasouza/Documents/Visualization/pythonProject3/Sample - Superstore.xls'
data = pd.read_excel(file_path)

# Set the figure size for better visibility
plt.figure(figsize=(12, 8))

# Create a bubble chart
# Here, we use 'Sales' as X-axis, 'Profit' as Y-axis, 'Quantity' as the size of the bubbles,
# and 'Category' to differentiate the bubbles with different colors.
sns.scatterplot(data=data, x="Sales", y="Profit", size="Quantity", hue="Category", alpha=0.5, sizes=(20, 2000), palette="bright")

# Enhance the chart for clarity
plt.title("Relationship between Sales and Profit by Category with Quantity as Bubble Size", fontsize=14)
plt.xlabel("Sales", fontsize=12)
plt.ylabel("Profit", fontsize=12)
plt.legend(title="Category", bbox_to_anchor=(1.05, 1), loc=2)
plt.grid(True)

# Show the plot
plt.tight_layout()
plt.show()
